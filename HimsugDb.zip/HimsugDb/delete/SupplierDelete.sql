USE [HimsugDB]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE SupplierDeleteSP
@SupplierID int
AS
BEGIN
Delete From Suppliers Where SupplierID = @SupplierID
END
GO


select * from Suppliers
