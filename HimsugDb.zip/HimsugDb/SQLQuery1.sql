USE HimsugDB
GO
/****** Object:  StoredProcedure [dbo].[Adding]    Script Date: 8/31/2023 7:21:54 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
Alter Procedure Product_Soft_Delete

alter table Products(
);
UPDATE items
SET is_deleted = 1
WHERE item_id = [your_item_id];